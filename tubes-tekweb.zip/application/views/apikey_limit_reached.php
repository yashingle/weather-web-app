<?php
    die('
        <p><strong>Layanan tidak tersedia. Mohon coba lagi.</strong> 🔃</p>
        <p>Jika sudah melakukan refresh berulang kali dan halaman tetap tidak ditampilkan, besar kemungkinan limit akses API telah tercapai. Kami menggunakan API dengan paket gratis yang mana aksesnya dibatas yaitu 150 request perhari. Mohon akses dihari lain. Mohon maaf atas ketidaknyamanannya. 🙏</p>
    ');
?>